var highestScore = 0;
var score = 0;

var idClicked = [];

$(document).ready( function() {
	
	 var obj = document.createElement("audio");
        obj.src="https://kahimyang.com/resources/sound/click.mp3";
        obj.volume=0.10;
        obj.autoPlay=false;
        obj.preLoad=true;       
		
	shuffleDiv();
	function shuffleDiv() {
		$("#gameholder").each(function(){
        var divs = $(this).find('div');
        for(var i = 0; i < divs.length; i++) $(divs[i]).remove();
		var divs = shuffle(divs);
		for(var i = 0; i < divs.length; i++) $(divs[i]).appendTo(this);
	});
	}
	
	function shuffle(array) {
		var currentIndex = array.length, temporaryValue, randomIndex;
		while (0 !== currentIndex) {
		randomIndex = Math.floor(Math.random() * currentIndex);
		currentIndex -= 1;
		temporaryValue = array[currentIndex];
		array[currentIndex] = array[randomIndex];
		array[randomIndex] = temporaryValue;
	  }
		return array;
	}	
    
	//This code will run after your page loads
	$('#gameholder').on('click', '*', function() {
	 var id = $(this).attr('id');
	 var flag = 0;
	 for(var i=0; i < idClicked.length; i++){
		 if (idClicked[i] == id) {
		 flag = 1;
		 break;
		 }
	 }
	 if (flag ==0) {
	 idClicked.push(id);
	 obj.play();
	 if(id.includes("penguin")){
		 console.log("hi"+score);
		 score += 1;
		 $('#score').empty();
		 $('#score').append(score);
		 $("#"+id).css("background-image", "url('./images/"+ id.substring(0, 7) + "_" + id.substring(7,9) + ".png");
	 } else {
		 idClicked = [];
		 if(score > highestScore){
		highestScore = score;
		
		
		$('#highestScore').empty();
		 $('#highestScore').append(highestScore);
		
	 } 
		score = 0;
		$('#score').empty();
		$('#score').append(score);
		 $("#gameholder").each(function(){
		 var divs = $(this).find('div');
        for(var i = 0; i < divs.length; i++){
			var id = $(divs[i]).attr('id');
			if(id != "yeti") {
			 $("#"+id).css("background-image", "url('./images/mound" + "_" + id.substring(7,9) + ".png");
			}
	}
		 });
		 shuffleDiv();
	 }
	 }
	});
});